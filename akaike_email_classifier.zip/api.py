from fastapi import FastAPI, Body
from pydantic import BaseModel
from masking import mask_pii_with_metadata
from utils import predict_category

app = FastAPI()

class EmailInput(BaseModel):
    email_text: str

@app.post("/classify")
def classify_email(input: EmailInput):
    raw_email = input.email_text
    masked_email, entities = mask_pii_with_metadata(raw_email)
    category = predict_category(masked_email)

    return {
        "input_email_body": raw_email,
        "list_of_masked_entities": entities,
        "masked_email": masked_email,
        "category_of_the_email": category
    }
