import pandas as pd
import joblib
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from masking import mask_pii_with_metadata

def train_model():
    df = pd.read_csv("data/emails.csv")
    df['masked_email'] = df['email'].apply(lambda x: mask_pii_with_metadata(str(x))[0])

    model = Pipeline([
        ("tfidf", TfidfVectorizer(stop_words="english")),
        ("clf", LogisticRegression(max_iter=300))
    ])
    model.fit(df['masked_email'], df['type'])
    joblib.dump(model, "email_classifier.pkl")
    print("✅ Model trained and saved!")

if __name__ == "__main__":
    train_model()
