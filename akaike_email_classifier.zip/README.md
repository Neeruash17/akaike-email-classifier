# 📩 Email Classification API (Akaike Assignment)

## 🔧 Setup
```bash
pip install -r requirements.txt
python model.py
uvicorn api:app --reload
```

## 📬 POST /classify

**Input:**
```json
{
  "email_text": "Hi, my name is Sneha Kapoor. My email is sneha@example.com. Card: 4111 1111 1111 1234"
}
```

**Output:**
```json
{
  "input_email_body": "...",
  "list_of_masked_entities": [...],
  "masked_email": "...",
  "category_of_the_email": "Billing Issues"
}
```
