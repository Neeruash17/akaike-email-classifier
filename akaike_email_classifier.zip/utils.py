import joblib
model = joblib.load("email_classifier.pkl")

def predict_category(masked_text):
    return model.predict([masked_text])[0]
